/**
 * Auto-configuration for multi-tenant resource servers.
 */
package io.quantics.multitenant;