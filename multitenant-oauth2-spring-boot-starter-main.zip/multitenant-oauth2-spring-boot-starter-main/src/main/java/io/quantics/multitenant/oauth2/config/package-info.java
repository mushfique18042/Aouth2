/**
 * Contains configuration classes for OAuth2-based multi-tenant applications.
 */
package io.quantics.multitenant.oauth2.config;