/**
 * Provides core interfaces for tenants in a multi-tenant application.
 */
package io.quantics.multitenant.tenantdetails;